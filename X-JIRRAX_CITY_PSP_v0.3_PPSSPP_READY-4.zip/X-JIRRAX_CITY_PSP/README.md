# X-JIRRAX CITY — PSP Homebrew (prototipe v0.3)

Prototipe game open-world PSP homebrew (C + PSPSDK), ditujukan untuk PPSSPP Android.
Kota fiktif 8×8 blok dengan arketipe Indonesia (kampung, pasar, ruko, masjid), jalan rusak, dan 64 NPC dengan jadwal harian. Ini masih **prototipe**, bukan game jadi.

## Cara menghasilkan file untuk PPSSPP (tanpa PC)

1. Buat repository GitHub baru.
2. Ekstrak ZIP proyek ini, lalu upload **isi folder `X-JIRRAX_CITY_PSP`** ke root repository. Pastikan `.github/workflows/build.yml` ikut ter-upload.
3. Buka tab **Actions** pada repository. Pilih workflow **Build EBOOT.PBP** lalu tekan **Run workflow** (atau lakukan commit/push agar workflow berjalan otomatis).
4. Tunggu sampai workflow selesai dengan status hijau.
5. Buka run yang berhasil, lalu unduh artifact **XJIRRAX_CITY_PPSSPP**.
6. Ekstrak ZIP artifact tersebut. Struktur di dalamnya sudah disiapkan seperti ini:
   `PSP/GAME/XJIRRAX_CITY/EBOOT.PBP`
7. Salin folder `XJIRRAX_CITY` ke folder `PSP/GAME/` pada Memory Stick PPSSPP. Jika folder `PSP/GAME` belum ada, buat foldernya.
8. Buka PPSSPP → **Games** → arahkan ke Memory Stick → buka `XJIRRAX_CITY`.

**Catatan:** ZIP proyek sumber ini bukan game yang bisa langsung dibuka PPSSPP. PPSSPP menjalankan hasil build `EBOOT.PBP`, bukan file `.c` atau ZIP source.

## Cara build dengan PC (opsional)

Pasang PSPSDK, buka terminal pada folder proyek, lalu jalankan:

```sh
make
```

Hasil yang diharapkan: `EBOOT.PBP` dan `XJIRRAX_CITY.elf`.

## Cek tanpa PSPSDK

```sh
sh tests/check.sh
```

Tes ini memeriksa sintaks C terhadap header PSP palsu dan logika host. Tes tersebut **bukan** pengganti build dengan PSPSDK asli dan bukan bukti game sudah berjalan di PPSSPP.

## Kontrol

Lihat `CONTROLS.txt`.

## Struktur kode

- `src/main.c` — loop utama (input → update → render)
- `src/callbacks.*` — exit callback sistem
- `src/input.*` — D-pad, stik analog, tombol aksi
- `src/render.*` — setup GU, palet material, `renderCube`
- `src/camera.*` — kamera chase di belakang mobil
- `src/world.*` — kota 8×8 blok: distrik, trotoar, zebra, jalan rusak
- `src/npc.*` — 64 NPC dengan jadwal harian dan rute di trotoar
- `src/vehicle.*` — fisika mobil sederhana dan model mobil

## Fitur prototipe saat ini

- Kamera chase orbit mengikuti mobil
- Mobil yang bisa dikendalikan (gas, rem, setir)
- Kota blok prosedural, tanpa aset eksternal
- Jalan, marka putus-putus, gedung dengan atap, pohon palem
- 64 NPC dengan jadwal dan rute

## Batasan yang diketahui

Belum ada tekstur, audio, interior bangunan, lalu lintas, misi, penyimpanan progres, HUD/menu lengkap, atau pengujian FPS di PPSSPP. Lihat `STATUS_PROJECT.md` untuk status dan daftar masalah yang diketahui.

Proyek ini original dan tidak memakai aset, peta, musik, atau file game GTA maupun game berhak cipta lain.
